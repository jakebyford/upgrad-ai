# app.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import pipeline
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

# Initialize FastAPI app
app = FastAPI(title="RAG Service with Sentence Transformers")

# Load LLM for text generation
print("Loading GPT-2 model...")
generator = pipeline("text-generation", model="gpt2")
print("GPT-2 model loaded.")

# Load Sentence Transformer for embeddings
print("Loading Sentence Transformer model...")
embedding_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
print("Sentence Transformer model loaded.")

# Example knowledge base (real-world: load from file or database)
DOCUMENTS = [
    "AI will transform industries by automating tasks.",
    "Generative AI creates text, images, and other content.",
    "FAISS is a library for efficient similarity search.",
    "LLMs can answer complex questions based on context.",
    "Vector databases store embeddings for quick retrieval."
]

# Create FAISS index
print("Creating FAISS index...")
dimension = 384  # Embedding size for 'all-MiniLM-L6-v2'
index = faiss.IndexFlatL2(dimension)

# Compute embeddings for the documents and add to the index
document_embeddings = embedding_model.encode(DOCUMENTS, convert_to_numpy=True)
index.add(np.array(document_embeddings, dtype="float32"))
print("FAISS index ready.")

# Define request and response schemas
class QueryRequest(BaseModel):
    query: str
    top_k: int = 3

@app.post("/query/")
async def query_rag(request: QueryRequest):
    try:
        # Generate embedding for the query
        query_embedding = embedding_model.encode([request.query], convert_to_numpy=True)
        
        # Search the FAISS index
        distances, indices = index.search(np.array(query_embedding, dtype="float32"), request.top_k)
        
        # Retrieve top documents
        top_docs = [DOCUMENTS[i] for i in indices[0]]

        # Generate response with the LLM
        prompt = f"Answer this based on context: {top_docs}. Query: {request.query}"
        response = generator(prompt, max_length=50, num_return_sequences=1)[0]["generated_text"]

        return {"query": request.query, "top_documents": top_docs, "response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
