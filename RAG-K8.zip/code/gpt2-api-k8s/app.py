# app.py
# Import necessary libraries
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import pipeline

# Initialize FastAPI app
app = FastAPI(title="GPT-2 Text Generation API")

# Load the GPT-2 model pipeline
print("Loading GPT-2 model...")
generator = pipeline("text-generation", model="gpt2")
print("Model loaded successfully.")

# Define a request body schema
class TextGenerationRequest(BaseModel):
    prompt: str
    max_length: int = 50
    num_return_sequences: int = 1

# Define the API endpoint for text generation
@app.post("/generate/")
async def generate_text(request: TextGenerationRequest):
    try:
        # Generate text
        generated_text = generator(
            request.prompt,
            max_length=request.max_length,
            num_return_sequences=request.num_return_sequences,
        )
        return {"generated_text": [text["generated_text"] for text in generated_text]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
