const sendButton = document.getElementById("send-btn");
const messageInput = document.getElementById("message-input");
const chatBox = document.getElementById("chat-box");


function appendMessage(message, sender){
    const messageElement = document.createElement("p");
    messageElement.textContent = `${sender}: ${message}`;

    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;

}

sendButton.addEventListener("click", async function(){
    const message = messageInput.value.trim();

    appendMessage(message, "You");

    try{
        const response = await fetch("http://localhost:8000/chat",{
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                "text": message
            })
        })

        const data = await response.json();
        console.log(data)
        appendMessage(data.response, "LLM Bot");
    }catch(error){
        console.log("Error")
        appendMessage("Error communicating with the server : ", error)
    }

    messageInput.value = "";
});