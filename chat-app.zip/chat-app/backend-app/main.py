# Create python virtual environment
# pip install virtualenv
# python -m venv venv
# source venv/bin/activate
# pip install fastapi uvicorn

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import httpx

app = FastAPI()

app.mount("/static", 
StaticFiles(directory="frontend"), 
name="frontend")

class User(BaseModel):
    display_name: str

class Message(BaseModel):
    text: str

@app.get("/info")
def info():
    return {"message": "Hello World, fastapi works!"}

@app.post("/chat")
async def chat(message: Message):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://127.0.0.1:8001/chat", json={"text": message.text}
        )
    return response.json()


@app.post("/set-name")
def set_name(name: User):
    return {"message": f"Hello {name.display_name}: Welcome to the chat app!"}