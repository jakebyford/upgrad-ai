# Create python virtual environment
# pip install virtualenv
# python -m venv venv
# source venv/bin/activate  
# pip install fastapi uvicorn langchain-openai langchain-community faiss-cpu

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel
from langchain.chains import RetrievalQA
from langchain_community.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI  
from langchain.prompts import PromptTemplate
from langchain.schema import HumanMessage  
import json

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

class ChatRequest(BaseModel):
    text: str

with open("data.json", "r") as file:
    data = json.load(file)

contents = [f"Question: {item['question']}\nAnswer: {item['answer']}" for item in data]
metadata = [{"answer": item["answer"]} for item in data]


openai_api_key = "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"

from langchain_openai import OpenAIEmbeddings

embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
vectorstore = FAISS.from_texts(contents, embeddings, metadatas=metadata)

retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.9, openai_api_key=openai_api_key)

@app.post("/chat")
def chat(request:ChatRequest):
    docs = retriever.get_relevant_documents(request.text)
    print(f"Retrieved Docs : {docs}")
    context = "\n".join([doc.page_content for doc in docs])
    messages = [
        HumanMessage(content=f"Context: {context} \n\n Question: {request.text}")
    ]
    response = llm(messages)
    return {"response": response.content}


@app.get("/info")
def info():
    return {"message": "Hello World, fastapi works!"}